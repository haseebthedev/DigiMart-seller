import React, { useState, useEffect } from "react";
import api from "../../../../Axios/api";
import MaterialTable from "material-table";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import {
	Grid,
	Paper,
	Modal,
	TextField,
	Container,
	Typography,
	Select,
	MenuItem,
	Button,
} from "@material-ui/core";
import { useUserContext } from "../../../../context/UserContext";

import DeleteProduct from "../../../FormDialog/DeleteProduct";

import useStyles from "./styles";
import Pal from "../../../../themes/palette";

export default function ViewProducts() {
	const classes = useStyles();
	// context
	const { store } = useUserContext();
	const token = store.data.token;

	// Snackbar
	const [snackBarstate, setSnackBar] = useState({
		open: false,
		vertical: "top",
		horizontal: "right",
		type: "success",
		message: "",
	});
	const { vertical, horizontal, open } = snackBarstate;
	const handleCloseSnackBar = () => {
		setSnackBar({ ...snackBarstate, open: false });
	};

	const [details, setDetails] = useState();

	const columns = [
		{ title: "Name", field: "name" },
		{ title: "Description", field: "description" },
		{ title: "Brand", field: "manufacturer" },
		{ title: "Category", field: "category" },
		{ title: "Price", field: "price" },
		{ title: "Stock", field: "stockAvailable" },
		{ title: "Discount", field: "discountPercentage" },
		{ title: "Warranty", field: "warranty" },
	];

	// category list retrive from DB
	const [productCategories, setProductCategories] = useState([
		{
			id: 0,
			name: "Sports",
		},
		{
			id: 1,
			name: "Electronics",
		},
		{
			id: 2,
			name: "Fashion",
		},
		{
			id: 3,
			name: "Outdoor",
		},
	]);

	const [productDetails, setProductDetails] = useState({
		name: "Feeder",
		description: "Amazing Product",
		manufactureDate: "11/06/2003",
		category: "Electronics",
		price: "1000",
		stockAvailable: 10,
		weight: 20,
		discountPercentage: 10,
		manufacturer: "Oppo china",
		warranty: "19 days",
		images: [],
		colors: [],
		storeName: "Jamal baby products",
	});

	// Modal Settings here
	const [modalOpen, setModelOpen] = useState(false);

	const handleOpen = () => {
		setModelOpen(true);
	};

	const handleClose = () => {
		setModelOpen(false);
	};

	useEffect(() => {
		api.get("/seller/store/products", {
			headers: { Authorization: `Bearer ${token}` },
		})
			.then((res) => {
				setDetails(res.data.data.products);
			})
			.catch((error) =>
				console.log(
					"ERROR: " + JSON.stringify(error.response.data.error)
				)
			);
	}, [token]);

	const [isDeletingProduct, setIsDeletingProduct] = useState(false);

	// show delete Account Dialog
	const handlerAccountDelete = () => {
		setIsDeletingProduct(true);
	};
	// Delete Account Handler
	const confirmedDelete = () => {
		setIsDeletingProduct(false);
	};

	return (
		<Grid container className={classes.root}>
			<Grid item xs={12} sm={12} md={12} component={Paper}>
				<MaterialTable
					title="All Products"
					data={details}
					columns={columns}
					actions={[
						(rowData) => ({
							icon: () => <EditIcon />,
							tooltip: "Edit",
							onClick: (event, rowData) => handleOpen(),
						}),
						(rowData) => ({
							icon: () => <DeleteIcon />,
							tooltip: "Delete",
							onClick: (event, rowData) => handlerAccountDelete(),
						}),
					]}
					options={{
						actionsColumnIndex: -1,
						// rowStyle: {
						// 	backgroundColor: "#EEE",
						// },
						headerStyle: {
							backgroundColor: Pal.palette.primary.main,
							color: "#fff",
						},
						exportButton: true,
					}}
				/>
				<Snackbar
					open={open}
					anchorOrigin={{ vertical, horizontal }}
					autoHideDuration={3000}
					onClose={handleCloseSnackBar}
					key={vertical + horizontal}
				>
					<MuiAlert
						elevation={6}
						variant="filled"
						onClose={handleCloseSnackBar}
						severity={snackBarstate.type}
					>
						{snackBarstate.message}
					</MuiAlert>
				</Snackbar>
			</Grid>

			<DeleteProduct
				DeletingProduct={isDeletingProduct}
				setDeletingProduct={setIsDeletingProduct}
				confirmedDelete={confirmedDelete}
			/>

			{/* Edit Product */}
			<Modal
				open={modalOpen}
				onClose={handleClose}
				onBackdropClick={handleClose}
				style={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
				}}
			>
				<Container component={Paper} maxWidth="md">
					<Grid container style={{ padding: 20 }} spacing={4}>
						<Typography variant="h5">Edit Product</Typography>
						<form className={classes.form} noValidate>
							<Grid container spacing={2}>
								<Grid item xs={12} sm={6} md={6} lg={6}>
									<TextField
										autoFocus
										margin="dense"
										variant="outlined"
										autoComplete="pName"
										required
										fullWidth
										label="Name"
										name="name"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={6}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										label="Brand"
										id="brandName"
										name="manufacturer"
									/>
								</Grid>
							</Grid>
							<Grid container spacing={2}>
								<Grid item xs={12} sm={12} md={12} lg={12}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										multiline
										rows={4}
										label="Description"
										name="description"
									/>
								</Grid>
							</Grid>
							<Grid container spacing={2}>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<Select
										variant="outlined"
										margin="dense"
										required
										fullWidth
										label="Category"
										name="category"
										style={{ marginTop: 8 }}
										defaultValue={"DEFAULT"}
									>
										<MenuItem value="DEFAULT" disabled>
											Choose a Product Category
										</MenuItem>
										{productCategories.map((el, index) => (
											<MenuItem
												value={el.name}
												key={index}
											>
												{el.name}
											</MenuItem>
										))}
									</Select>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										placeholder="Blue, Red etc."
										label="Colors"
										name="colors"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										placeholder="dd/MM/YYYY"
										label="Manufacture Date"
										name="manufactureDate"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										placeholder="Weight"
										label="Weight"
										name="weight"
									/>
								</Grid>
							</Grid>
							<Grid container spacing={2}>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										label="Price (Rs)"
										name="price"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										name="stock"
										label="Stock / Quantity"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										name="warranty"
										label="Warranty"
									/>
								</Grid>
								<Grid item xs={12} sm={6} md={6} lg={3}>
									<TextField
										variant="outlined"
										margin="dense"
										required
										fullWidth
										label="Discount(%)"
										id="discount"
										name="discount"
									/>
								</Grid>
							</Grid>
							<div
								style={{
									display: "flex",
									alignItems: "center",
									marginTop: 20,
									marginBottom: 20,
									padding: 20,
									border: "1px solid #c4c4c4",
									borderRadius: 6,
								}}
							>
								<Grid
									container
									spacing={4}
									justify="center"
									style={{ margin: "10px 0" }}
								>
									<Grid item>
										<input
											type="file"
											multiple
											accept="image/png, image/jpeg"
										/>
									</Grid>
								</Grid>
								<Grid container justify="center">
									<div
										style={{
											display: "flex",
										}}
									>
										{productDetails.images.length > 0 ? (
											productDetails.images.map(
												(img, index) => (
													<Grid item key={index}>
														<img
															src={img}
															alt="product-images"
															height="100px"
															style={{
																border: "1px solid black",
																marginRight:
																	"20px",
															}}
														/>
													</Grid>
												)
											)
										) : (
											<Typography>
												Upload Product Images
											</Typography>
										)}
									</div>
								</Grid>
							</div>
							<Button
								size="large"
								type="submit"
								variant="contained"
								color="primary"
							>
								Add Product
							</Button>
							<Snackbar
								open={open}
								anchorOrigin={{ vertical, horizontal }}
								autoHideDuration={3000}
								onClose={handleCloseSnackBar}
								key={vertical + horizontal}
							>
								<MuiAlert
									elevation={6}
									variant="filled"
									onClose={handleCloseSnackBar}
									severity={snackBarstate.type}
								>
									{snackBarstate.message}
								</MuiAlert>
							</Snackbar>
						</form>
					</Grid>
				</Container>
			</Modal>
		</Grid>
	);
}
